#include "p3220043-p3220118-p3220022-pizza.h"


//mutex for the sum(shop's incomes)
pthread_mutex_t lock_sum;
pthread_cond_t  cond_sum;

//mutex for the cooling time(deliver time - bake time)
pthread_mutex_t lock_coolingtime;
pthread_cond_t  cond_coolingtime;

//mutex for the sum of successful orders
pthread_mutex_t lock_csuccess;
pthread_cond_t  cond_csuccess;

//mutex for the sum of failed orders
pthread_mutex_t lock_cfail;
pthread_cond_t  cond_cfail;

//mutex for the sum of deliver time and max deliver time 
pthread_mutex_t lock_sumservice;
pthread_cond_t  cond_sumservice;

//mutex for the screen
pthread_mutex_t lock_screen;
pthread_cond_t  cond_screen;

//mutex for counter peperoni
pthread_mutex_t lock_peperoni;
pthread_cond_t  cond_peperoni;

//mutex for counter margarita
pthread_mutex_t lock_margarita;
pthread_cond_t  cond_margarita;

//mutex for counter special
pthread_mutex_t lock_special;
pthread_cond_t  cond_special;

//mutex for the tel
pthread_mutex_t lock_tel;
pthread_cond_t  cond_tel;

//mutex for the cook
pthread_mutex_t lock_cook;
pthread_cond_t  cond_cook;

//mutex for the ovens
pthread_mutex_t lock_oven;
pthread_cond_t  cond_oven;

//mutex for the delivery
pthread_mutex_t lock_deliverer;
pthread_cond_t  cond_deliverer;




void *order(void *x)
{
    struct timespec  pack_end_time, deliver_end_time, thread_start_time, payment_wait_time, payment_end_time,bake_end_time;//struct type of timespec
    		      //pack_end_time=take the packing end time
    		      //deliver_end_time=the time when the deliverer has deliver the order to the consumer 
    		      //thread_start_time=the creation's time of the  thread
    		      //payment_wait_time=delay time until we fulfil the payment (payment_end_time.tv_sec - thread1_start_time.tv_sec)
    		      //payment_end_time=the time when we fulfil the payment
    		      //bake_end_time=the time we finished to bake the order's pizzas

	

    int pid = *(int *)x; // the unique code of each order
    int newseed=seed+pid;//newseed=seed(argument of the user)+id
    int  i;//rc=a number which is returned after the create,lock . defines if everything went well , without problems
    bool flag=false;//flag that informs about the status of payment (false=payment failed ,true=payment succeded )
    
    
    
    rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
    printf("The order %d just started\n", pid);
    rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock the resource
    rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"

    
    
    
    if (pid==1){//the first thread(order)
        if (clock_gettime(CLOCK_REALTIME, &thread1_start_time)==-1)//if something went wrong getting the current time, thread1_start_time=the creation's time of the first thread
        {
            rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
            perror("clock_gettime");
            rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock the resource
            rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
            return 1;
        }
    
    }
    
    if (clock_gettime(CLOCK_REALTIME, &thread_start_time)==-1)
    {
    	    //if something went wrong getting the current time, thread_start_time=the creation's time of the  thread,except the first
            rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the the resource
            perror("clock_gettime");
            rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock the resource
            rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
            return 1;
    }
    

    
    //==================================CALL=============================================================
    rc=pthread_mutex_lock(&lock_tel);//locks the resource(tel)
    
    while (Ntel == 0)//when there is not available resource(tel) then wait until someone is free
    {
        rc=pthread_cond_wait(&cond_tel, &lock_tel);
    }
    
    Ntel--;//we have available resource(tel),we use one resource.so we have one less resource
    
    rc=pthread_mutex_unlock(&lock_tel);//we now do not need the resource(tel) . so we unlock the the resource
    
    //quantity of pizza
    int quantitypizza = (rand_r(&seed) %Norderhigh)+Norderlow;// we select randomly the amount of pizza which is between 1 to 5
    
    rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the  resource
    printf("quantity: %d for order %d\n", quantitypizza, pid );
    rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock it (screen)
    rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"



    
    int *arraypizza, percent;//arraypizza=ia a array in which we save the type of each pizza
		  	     //percent=the percent which determines the type of each pizza.[0,35] is margarita,[36,60] is peperroni,[61,100] is special    
			     //1=peperoni
			     //2=margarita
			     //3=special
    
    //malloc
    arraypizza =(int*) malloc(quantitypizza * sizeof(int));//we create space in memory for the arraypizza which contains integers(the type of pizza)
    
    //pizza type
    for (i=0; i<quantitypizza; i++)
    {
        percent=(rand_r(&newseed) %100)+1;//percent which determines the type of pizza

        if (percent <= Pp)//if percent is betweeen [0,25] then is peperoni
        {
            arraypizza[i]=1; // 1=peperoni
            rc=pthread_mutex_lock(&lock_peperoni);//we now need the resource(peperoni) . so we lock the resource
            totalcountpeperoni=totalcountpeperoni+1;//increase the total amount of peperoni
            rc=pthread_mutex_unlock(&lock_peperoni);//we now do not need the resource(peperoni) . so we unlock the resource
            rc=pthread_cond_signal(&cond_peperoni);//it wakes up one of the threads that are waiting on condition variable "cond_peperoni"
            

            
            rc=pthread_mutex_lock(&lock_sum);//we now need the resource(sum=incomes) . so we lock the resource
            sum=sum+Cp;//increase the sum of total incomes + the price of a peperoni
            rc=pthread_mutex_unlock(&lock_sum);//we now do not need the resource(sum) . so we unlock the resource
            rc=pthread_cond_signal(&cond_sum);//it wakes up one of the threads that are waiting on condition variable "cond_sum"
           

        } 
        else if (percent <= Pm + Pp) //if percent is betweeen [26,60] then is margarita
        {
            arraypizza[i]=2; // 2=margarita
     
            rc=pthread_mutex_lock(&lock_margarita);//we now need the resource(margarita) . so we lock the resource
            totalcountmargarita=totalcountmargarita+1;//increase the total amount of margarita
            rc=pthread_mutex_unlock(&lock_margarita);//we now do not need the resource(margarita) . so we unlock the resource
            rc=pthread_cond_signal(&cond_margarita);//it wakes up one of the threads that are waiting on condition variable "cond_margarita"
            

            rc=pthread_mutex_lock(&lock_sum);//we now need the resource(sum) . so we lock the resource
            sum=sum+Cm;//increase the sum of total incomes + the price of a margarita
            rc=pthread_mutex_unlock(&lock_sum);//we now do not need the resource . so we unlock the resource
            rc=pthread_cond_signal(&cond_sum);//it wakes up one of the threads that are waiting on condition variable "cond_sum"
           

        } 
        else //percent is between [61,100] then is special
        {
            arraypizza[i]=3; // 3=special

            rc=pthread_mutex_lock(&lock_special);//we now need the resource(special) . so we lock the resource
            totalcountspecial=totalcountspecial+1; //increase the total amount of special
            rc=pthread_mutex_unlock(&lock_special);//we now do not need the resource . so we unlock the resource
            rc=pthread_cond_signal(&cond_special);//it wakes up one of the threads that are waiting on condition variable "cond_special"
         
        
            rc=pthread_mutex_lock(&lock_sum);//we now need the resource(sum) . so we lock the resource
            sum=sum+Cs;//increase the sum of total incomes + the price of a special
            rc=pthread_mutex_unlock(&lock_sum);//we now do not need the resource . so we unlock the resource
            rc=pthread_cond_signal(&cond_sum);//it wakes up one of the threads that are waiting on condition variable "cond_sum"
            

        }
        
        
    }
    
    
    //time for payment
    int timepayment = (rand_r(&newseed) %Tpaymenthigh)+Tpaymentlow;//we select a random number which is between[1,3] for the caller to charge the card
    sleep(timepayment);//for this time (until to finish the charge) we put them to sleep 

    rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the  resource
    printf("payment took %d min\n",timepayment);
    rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock the  resource
    rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
    

    
    int percentfail = (rand_r(&newseed) %100)+1;//we create a random percent between [1,100] if the order(card) is failed

    //we take the payment_end_time=the time when we fulfil the payment (is the time now)
    if (clock_gettime(CLOCK_REALTIME, &payment_end_time)==-1)
    {
        rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
        perror("clock_gettime");
        rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock  the resource
        rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"        
        return 1;
    }
        
    //wait time until we fulfil the payment (payment_end_time.tv_sec - thread1_start_time.tv_sec)
    payment_wait_time.tv_sec = payment_end_time.tv_sec - thread1_start_time.tv_sec;
    if (payment_wait_time.tv_nsec<0)
    {
        payment_wait_time.tv_sec--;
    }
        
    //the delay of the payment-creation(failed/successed)
    total_wait_minutes=payment_wait_time.tv_sec;
    int total_wait_minutes_int = (int)total_wait_minutes;// Cast to int
    int h = total_wait_minutes_int / 60;  // Calculate the number of full hours(useful to format)
    int minutes = total_wait_minutes_int % 60;  // Calculate the remaining minutes(useful to format)
 
    // Check if the order failed
    if (percentfail <= 5) 
    {
    	
    	rc=pthread_mutex_lock(&lock_cfail);//we now need the resource(cfail) . so we lock the resource
        cfail=cfail+1;//we increase the amount of the failed orders
        rc=pthread_mutex_unlock(&lock_cfail);//we now do not need the resource(failed orders) . so we unlock the resource
        rc=pthread_cond_signal(&cond_cfail);//it wakes up one of the threads that are waiting on condition variable "cond_cfail"
    	
        if (total_wait_minutes_int < 60) 
        {
            rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
            printf("Order with number %d FAILED the moment : %d:%02d\n", pid, h, minutes);
            rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock the resource
            rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
           
        } else{
            rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
            printf("Order with number %d FAILED the moment :  %d:%02d\n", pid, h, minutes);
            rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock the resource
            rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
           
        }
       
    } else {
    
        // Order succeeded
        rc=pthread_mutex_lock(&lock_csuccess);//we now need the resource(counter of the successful orders) . so we lock the resource
        csuccess=csuccess+1;//increase the amount of the successful orders
        rc=pthread_mutex_unlock(&lock_csuccess);//we now do not need the resource . so we unlock the resource
        rc=pthread_cond_signal(&cond_csuccess);//it wakes up one of the threads that are waiting on condition variable "cond_csuccess"


        if (total_wait_minutes_int < 60) 
        {
            rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
            printf("The order with number %d APPROVED the moment : %d:%02d\n", pid, h, minutes);
            rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock the resource
            rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
            
        } else {
            rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
            printf("The order with number %d APPROVED the moment :  %d:%02d\n", pid, h, minutes);
            rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource(screen) . so we unlock the resource
            rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
            
        }
     
        flag = true; // Set flag to true(the order has been approved)
    }
    free(arraypizza);//now we do not need the arraypizza so we release the memory which was reserved for this
    rc=pthread_mutex_lock(&lock_tel);//now we have to reserve the Ntel , so we lock it
    Ntel++;//we have release the phoner and now we have to increase it 
    rc=pthread_mutex_unlock(&lock_tel);//now we do not need the resource , so we unlock this
    rc=pthread_cond_signal(&cond_tel);//it wakes up one of the threads that are waiting on condition variable "cond_tel"
   
    
    
    //=====================================COOKER===============================================================
    if(flag==true)
    {//if the payment is succeded
       
        rc=pthread_mutex_lock(&lock_cook);//we now need the resource(cooker) . so we lock the resource
        
        while (Ncook == 0)
        {//when there is not available resource then wait until someone is free
            rc=pthread_cond_wait(&cond_cook, &lock_cook);
        }
        
        Ncook--;//we use one resource(cooker).so we have one less resource
    
        rc=pthread_mutex_unlock(&lock_cook);//we now do not need the resource(cooker) . so we unlock the resource      
        rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
        printf("preparing order %d for %d minutes\n",pid, Tprep*quantitypizza);
        rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource(screen) . so we unlock the resource
        rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
        rc=pthread_mutex_unlock(&lock_screen);//now we do not need the resource , so we unlock this
    
        sleep(Tprep*quantitypizza);//sleep the order to prepare the order
        
        //when we have prepare the oeder is time to bake them 
        
        rc=pthread_mutex_lock(&lock_oven);//we now need the resource(ovens) . so we lock the resource
        
        while (Noven == 0 || Noven<quantitypizza)
        {//when there is not available resource then wait until someone is free                    
            rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
            printf("order %d is waiting to ovens to be free\n", pid);
            rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource(screen) . so we unlock the resource
            rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"    
            rc=pthread_cond_wait(&cond_oven, &lock_oven); //when there is not available resource then wait until someone is free             
        }
            
        
        //============================================COOKER=========================================================
        //there is the necessary amount of resource=cooker
        rc=pthread_mutex_lock(&lock_cook);//we now need the resource(cooker) . so we lock the resource
        Ncook++;//we use one resource.so we have one less resource
        rc=pthread_mutex_unlock(&lock_cook);//we now do not need the resource(cooker) . so we unlock the resource
        rc=pthread_cond_signal(&cond_cook);//it wakes up one of the threads that are waiting on condition variable "cond_cook"
        
            
        //===============================================OVENS======================================================
        
        Noven=Noven-quantitypizza;//the free ovens=the current free ovens - the order's amount of pizza
     
        rc=pthread_mutex_unlock(&lock_oven);//we now do not need the resource(ovens) . so we unlock the resource
        sleep(Tbake);//wait till all pizzas are baked 
            
    	if (clock_gettime(CLOCK_REALTIME, &bake_end_time)==-1)//try to take the current time=the time we finished to bake the order's pizzas
        {            
            rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
            perror("clock_gettime");//something went wrong 
            rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource(screen) . so we unlock the the resource
            rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
            return 1;
        }
        
        
        //===============================================DELIVERER================================================
        //pizzas are baked and now is time to deliver them
        rc=pthread_mutex_lock(&lock_deliverer);//we now need the resource(deliverers) . so we lock the resource
        while (Ndeliverer == 0 )
        {//when there is not available resource then wait until someone is free
            rc=pthread_cond_wait(&cond_deliverer, &lock_deliverer); 
        }
        
        //================================================OVENS==============================================================
        //the deliverer is available. we need to free the ovens 
        rc=pthread_mutex_lock(&lock_oven);//we now need the resource(ovens) . so we lock the resource
        Noven=Noven+quantitypizza;//we use one resource(ovens).so we have more ovens as the quantity of the order
        rc=pthread_mutex_unlock(&lock_oven);//we now do not need the resource(ovens) . so we unlock the  resource
        rc=pthread_cond_signal(&cond_oven);//it wakes up one of the threads that are waiting on condition variable "cond_oven"
        
        
        //==============================================DELIVERER=============================================================
        
        Ndeliverer--;//we have available a deliverer. so we have to decrease the available deliverers 
        rc=pthread_mutex_unlock(&lock_deliverer);//we now do not need the resource(deliverers) . so we unlock the resource
        sleep(Tpack*quantitypizza);//we need to pack the pizzas.
        
        rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
        printf("packed in %d min\n", Tpack*quantitypizza);//time for packing all pizzas
        rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource(screen) . so we unlock the resource
        rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
        
       //we want to take the packing end time ,which is the current time 
        if (clock_gettime(CLOCK_REALTIME, &pack_end_time)==-1)//if something went wrong
        {          
            rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the  resource
            perror("clock_gettime");
            rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource(screen) . so we unlock the resource
            rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
          
            return 1;
        }
        
       //the order has been packed
       //we need the how many minutes was the time of packing for the whole order (packing finished time-start time)	
        rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
        printf("The order with number %d is READY in %d minutes\n", pid, pack_end_time.tv_sec-thread_start_time.tv_sec);
        rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource(screen) . so we unlock  the resource
        rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"

            
            
        //random time for the deliverer to deliver the order 
        int delivertime = (rand_r(&newseed) %Tdelhigh)+Tdellow;

        //time for the deliverer to deliver the order
        sleep(delivertime);
        
        
        rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
        printf("deliver for order %d took %d minutes\n",pid, delivertime);
        rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource(screen) . so we unlock the resource
        rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
        
        
        //deliver end time=the time when the deliverer has deliver the order to the consumer 
        if (clock_gettime(CLOCK_REALTIME, &deliver_end_time)==-1)
        {   //if something went wrong
            rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
            perror("clock_gettime");
            rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock the resource
            rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
                      
            return 1;
        }

        rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
        printf("The order with number %d DELIVERED to  %d minutes\n", pid,deliver_end_time.tv_sec-thread_start_time.tv_sec);
        rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock the resource
        rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
        
            
 	//cooling time, max cooling time, total cooling time
        rc=pthread_mutex_lock(&lock_coolingtime);//we now need the resource(coolingtime) . so we lock the resource
        if (deliver_end_time.tv_sec-bake_end_time.tv_sec>maxcoolingtime)//find the max coolingtime
        {
		maxcoolingtime=deliver_end_time.tv_sec-bake_end_time.tv_sec;
	}
        sumcoolingtime=sumcoolingtime+deliver_end_time.tv_sec-bake_end_time.tv_sec;//increase the cooling time
        rc=pthread_mutex_unlock(&lock_coolingtime);//we now do not need the resource(coolingtime) . so we unlock the resource
        rc=pthread_cond_signal(&cond_coolingtime);//it wakes up one of the threads that are waiting on condition variable "cond_coolingtime"
       
        
        //service time, max service time, total service time  
	rc=pthread_mutex_lock(&lock_sumservice);//we now need the resource(sumservice) . so we lock the resource
	if (deliver_end_time.tv_sec-thread_start_time.tv_sec>maxservicetime)//find the max service time
	{
		maxservicetime=deliver_end_time.tv_sec-thread_start_time.tv_sec;
	}
        sumservicetime=sumservicetime+deliver_end_time.tv_sec-thread_start_time.tv_sec;//increase the sum service time
        rc=pthread_mutex_unlock(&lock_sumservice);//we now do not need the resource(sumservice) . so we unlock the resource
        rc=pthread_cond_signal(&cond_sumservice);//it wakes up one of the threads that are waiting on condition variable "cond_sumservice"
           
        // the order has been delivered
        rc=pthread_mutex_lock(&lock_deliverer);//we now need do not need the resource(deliverer) . so we lock  the resource
        Ndeliverer++;//we do not  use the resource
        rc=pthread_mutex_unlock(&lock_deliverer);//we now do not need the resouece(deliverer) . so we unlock  the resource
        rc=pthread_cond_signal(&cond_deliverer);//it wakes up one of the threads that are waiting on condition variable "cond_deliverer"
        
        
    }
  
    pthread_exit(NULL);//we exit the thread
    return 0;
}

//======================================================================MAIN==========================================================================================
int main(int argc, char *argv[])
{

    int arraysize, *randomArray, i,rc;//arraysize=the amount of the consumers,randomArray=number between[1,5] which is the time of the next call,i=counter for the for loops,rc=an integer created after lock,unlock,create of a thread
    
    //checks for arguments
    if (argc!=3)
    {//if the amount of arguments is >3 (name of the funcion,the number of the consumers, the  random seed) then print a error message
        
        rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
        printf("ERROR: the program should take 2 arguments, the number of consumers and the seed!\n");
        rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock it
        rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
        exit(-1);
    }
    
    arraysize =atoi(argv[1]);// cast the argument of type char to int 
    seed =atoi(argv[2]);//cast the argument of type char to int 
    

    if (arraysize<1)
    {//if the number of concumers is not in [1,100] then print a error message     
        rc=pthread_mutex_lock(&lock_screen);//we now need the resouece . so we lock the resource
        printf("ERROR: the number of threads to run should be a positive number!\n");
        rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock the resource
        rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_tel"
        exit(-1);
    }
    
    //malloc 
    pthread_t *threads;//we reserve space to save the threads 
    threads = malloc(arraysize * sizeof(pthread_t));
    
    if (threads==NULL)
    {//if there is not the address of this table then print a error message(there is not enough memory)
        rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
        printf("Not enough memory\n");
        rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock the resource
        rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
    }


    //malloc
    randomArray =(int*) malloc(arraysize * sizeof(int));//we reserve the necessary space for the randomArray
    
    //srand(seed);
    for (i=0;i<arraysize;i++)
    {
        randomArray[i]= (rand_r(&seed) %Torderhigh)+Torderlow;;//randomArray =number between[1,5] which is the time of the next call
    }

    //create threads 
    int *parametroi = malloc(arraysize* sizeof(int));//we reserve the necessary space for the table parametroi which contains the unique code for each thread(number of the thread:1,2,3...)
    
    
    if (parametroi==NULL)
    {//if there is not enough memory
        rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the resource
        perror("Failed to allocate memory");
        rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock it
        rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
        free(threads);//we free(delete)the threads
      return 1;
    }
    for (i=0; i<arraysize; i++)
    {
        parametroi[i]=i+1;//we complete the table with the unique code for each thread(number of the thread:1,2,3...)
        //create tread
        rc = pthread_create(&threads[i], NULL, order, &parametroi[i]);//we create the thread using the method pthread_create
        if (rc!=0)
        {//if something went wrong in creation of the threads then print a error message and delete(free) the arrays (parametroi,threads)       
            rc=pthread_mutex_lock(&lock_screen);//we now need the resouerce . so we lock the the resource
            perror("Failed to create thread");
            rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource(screen) . so we unlock the the resource
            rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
            //free(delete)the array's memory
            free(parametroi);
            free(threads);
            free(randomArray);         
            return 1;
        }

        //when in the last order you dont have random time for the next order there is no next order 
        // in the last order (thread) we can not do this parametroi[i]=i+1 because there is not i+1
        if (i!=arraysize-1)//if we are not in the last order we put it to sleep for randomArray[i+1] which is the time until the next call
        {
            sleep(randomArray[i+1]);
        }
    
    }
    
    //join threads
    int *status, rc1;//*status=necessary argument for the thread's join,rc1=integer number after the join of the first thread
    for (int i = 0; i < arraysize; i++) 
    {//for each thread and we join them
           rc1 = pthread_join(threads[i], &status);
           if (rc1!=0)
           {// if something went wrong(return value is !=0) then print a error message
		    rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock the  resource
		    perror("Failed to join thread");
		    rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock it
		    rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
		    free(parametroi);//free(delete) the tables of parametroi and threads
		    free(threads);
		    free(randomArray);
		    return 1;
           }
    }
        
    int avgservicetime;//average service time
    if (csuccess!=0)//if the amount of the successful orders is 0
    {
        avgservicetime=sumservicetime/csuccess;//calculate the average service time
    }
    
    int avgcoolingtime;//average cooling time
    if (csuccess!=0)//if the amount of the successful orders is 0
    {
        avgcoolingtime=sumcoolingtime/csuccess;//calculate the average cooling time
    }   
        
        
    rc=pthread_mutex_lock(&lock_screen);//we now need the resource(screen) . so we lock it
    printf("Total income is: %d\n",sum);
    printf("Amount of peperoni: %d\n",totalcountpeperoni);
    printf("Amount of margarita: %d\n",totalcountmargarita);
    printf("Amount of special: %d\n",totalcountspecial);
    printf("Amount of successful orders: %d\n",csuccess);
    printf("Amount of failed orders: %d\n",cfail);
    printf("Average time of service: %d\n",avgservicetime);
    printf("Max time of service: %d\n",maxservicetime);
    printf("Average time of cooling: %d\n",avgcoolingtime);
    printf("Max time of cooling: %d\n",maxcoolingtime);
    rc=pthread_mutex_unlock(&lock_screen);//we now do not need the resource . so we unlock the the resource
    rc=pthread_cond_signal(&cond_screen);//it wakes up one of the threads that are waiting on condition variable "cond_screen"
    
    //free(delete) the tables of parametroi and threads
    free(parametroi);    
    free(threads);
    free(randomArray);
    return 0;
    
}

