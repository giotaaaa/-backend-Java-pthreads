#pragma once
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <stdbool.h>



int Ntel=2;//resources of the tel
int Ncook=2; //resources makers
int Noven=10; //resources ovens
int Ndeliverer=10; //resources deliverers
int Torderlow=1;//under limit time for the next consumer's call
int Torderhigh=5;//high limit time for the next consumer's call
int Norderlow=1;//under limit for the order's amount 
int Norderhigh=5;//high limit for the order's amount 
int Pm=35;//propability for pizza=margarita
int Pp=25;//propability for pizza=peperoni
int Ps=40;//propability for pizza=special
int Tpaymentlow=1;//under limit for debit's time
int Tpaymenthigh=3;//high limit for debit's time
int Pfail=5;//propability to fail the payment
int Cm=10;//price for pizza margarita
int Cp=11;//price for pizza peperroni
int Cs=12;//price for pizza special 
int Tprep=1;//time of preparing
int Tbake=10;//time for bake
int Tpack=1;//time for packing
int Tdellow=5;//under limit for deliver's time
int Tdelhigh=15;//high limit for deliver's time
int seed;//the argument of the user  to create random numbers
int rc;//number produced after doing something in a thread(crate,lock,unlock)
int totalcountpeperoni=0;//counter of total amount of peperoni
int totalcountmargarita=0;//counter of total amount of margarita
int totalcountspecial=0;//counter of total amount of special
int sum=0;//the sum of the incomes of the whole store 
int csuccess=0;//the amount of successful orders
int cfail=0;//the amount of failed orders
int sumservicetime=0;//sum of the service time for all the orders to calculate the avg(deliver time - creation of the order)
int maxservicetime=0;//max service time (deliver time - creation of the order)
int sumcoolingtime=0; //sum of the cooling time for all the orders to calculate the avg(deliver time - bake time)   
int maxcoolingtime=0;//max cooling time (deliver time - bake time)

struct timespec thread1_start_time;//is a struct, type of timespec where thread1_start_time = the creation's time of the first thread

double total_wait_minutes;//minutes of delay(time of fail/success - creation of the thread)

void *order(void *x);//the method which control the resources
